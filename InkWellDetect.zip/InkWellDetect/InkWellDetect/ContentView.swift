//
//  ContentView.swift
//  InkWellDetect
//
//  Created by 5paisa on 21/05/24.
//

import SwiftUI
import Flutter

    
struct ContentView: View {
    @State private var showFlutterView = false

    var body: some View {
        VStack {
            Button("Add Flutter View") {
                showFlutterView.toggle()
            }
            if showFlutterView {
                FlutterViewWrapper()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }
}
    
struct FlutterViewWrapper: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIViewController {
        let flutterViewController = FlutterViewController()
        // Additional configuration if needed
        return flutterViewController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // Update logic if needed
    }
}

